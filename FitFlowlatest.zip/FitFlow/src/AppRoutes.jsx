import { Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Registration from "./pages/Registration";
import UsersList from "./pages/UsersList";
import Login from "./pages/Login";
import FitnessPlans from "./pages/FitnessPlans";
import NutritionGuidance from "./pages/NutritionGuidance";
import WellnessMarketplace from "./pages/WellnessMarketplace";
import LiveCoaching from "./pages/LiveCoaching";
import HealthTracking from "./pages/HealthTracking";

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/registration" element={<Registration />} />
      <Route path="/login" element={<Login />} />
      <Route path="/users" element={<UsersList />} />
      <Route path="/fitness-plans" element={<FitnessPlans />} />
      <Route path="/nutrition-guidance" element={<NutritionGuidance />} />
      <Route path="/wellness-marketplace" element={<WellnessMarketplace />} />
      <Route path="/live-coaching" element={<LiveCoaching />} />
      <Route path="/health-tracking" element={<HealthTracking />} />
    </Routes>
  );
}
