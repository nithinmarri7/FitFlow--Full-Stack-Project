import { useEffect, useState } from "react";
import "../Components/NutritionGuidance.css";
export default function NutritionGuidance() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const u = JSON.parse(localStorage.getItem("user"));
    setUser(u);
  }, []);

  return (
    <div className="nutrition-wrapper">
      <h2 className="nutrition-title">🥗 AI Nutrition for {user?.fullName}</h2>
      <p className="nutrition-desc"> Your diet preference: <b>{user?.dietPreference}</b></p>
      <ul className="nutrition-list">
        <li>🍳 High protein meals like eggs, chicken, tofu</li>
        <li>🥦 Include fiber-rich vegetables</li>
        <li>🥤 Stay hydrated - 3L water daily</li>
        <li>🥜 Consider protein shakes post workout</li>
      </ul>
    </div>
  );
}
