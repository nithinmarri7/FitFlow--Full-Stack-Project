import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";
import OfferSection from "../Components/OfferSection";
import About from "../Components/About";
import Services from "../Components/Services";
import "./Home.css";
import "../Components/Login.css";
import { Link } from "react-router-dom";

export default function Home() {
  return (
    <>
      <Navbar />

      <section id="home">
        <OfferSection />
      </section>

      <section id="about">
        <About />
      </section>

      <section id="services">
        <Services />
      </section>

      {/* Register and Login Buttons */}
      <div className="text-center my-6">
        <Link to="/registration">
          <button style={{ 
            padding: "10px 20px", 
            background: "green", 
            color: "white", 
            borderRadius: "5px", 
            marginRight: "10px",
            border: "none",
            cursor: "pointer"
          }}>
            Register
          </button>
        </Link>
        <Link to="/login">
          <button style={{ 
            padding: "10px 20px", 
            background: "blue", 
            color: "white", 
            borderRadius: "5px",
            border: "none",
            cursor: "pointer"
          }}>
            Login
          </button>
        </Link>
      </div>

      <Footer />
    </>
  );
}
