import { useEffect, useState } from "react";
import "../Components/LiveCoaching.css";
export default function LiveCoaching() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const u = JSON.parse(localStorage.getItem("user"));
    setUser(u);
  }, []);

  return (
    <div className="component-wrapper">
      <h2 className="component-title">🎥 Live Coaching for {user?.fullName}</h2>
      <p className="component-desc">Upcoming sessions:</p>
      <ul className="component-list">
        <li>📅 Monday: Full-body workout at 7 PM</li>
        <li>📅 Wednesday: Strength Training at 6 PM</li>
        <li>📅 Friday: Yoga & Recovery at 8 AM</li>
        <li>🧑‍🏫 Book expert 1:1 coaching anytime</li>
      </ul>
    </div>
  );
}