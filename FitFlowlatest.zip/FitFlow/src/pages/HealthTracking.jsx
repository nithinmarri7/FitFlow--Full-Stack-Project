import { useEffect, useState } from "react";
import "../Components/HealthTracking.css";
export default function HealthTracking() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const u = JSON.parse(localStorage.getItem("user"));
    setUser(u);
  }, []);

  return (
    <div className="component-wrapper">
      <h2 className="component-title">📈 Health Tracking for {user?.fullName}</h2>
      <p className="component-desc">
        Tracking your wellness journey. Keep up the great work!
      </p>
      <ul className="component-list">
        <li>🛌 Sleep: Avg 7.5 hours/night</li>
        <li>💧 Water intake: 2.9L/day</li>
        <li>🦶 Steps: 10,000+ steps/day</li>
        <li>🍽️ Meals logged: 90% this week</li>
        <li>💓 Heart rate: Normal (Avg 72 bpm)</li>
      </ul>
    </div>
  );
}