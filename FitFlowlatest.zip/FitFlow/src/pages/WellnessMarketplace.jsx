import { useEffect, useState } from "react";
import "../Components/WellnessMarketPlace.css";
export default function WellnessMarketplace() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const u = JSON.parse(localStorage.getItem("user"));
    setUser(u);
  }, []);

  return (
    <div className="component-wrapper">
      <h2 className="component-title">🛍️ Wellness Marketplace for {user?.fullName}</h2>
      <p className="component-desc">Recommended wellness items:</p>
      <ul className="component-list">
        <li>🍵 Herbal teas and detox drinks</li>
        <li>🧴 Organic skincare and essential oils</li>
        <li>🍽️ Portion control plates and bottles</li>
        <li>📦 Protein powders and supplements</li>
      </ul>
    </div>
  );
}