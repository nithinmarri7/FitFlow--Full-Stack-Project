import { useEffect, useState } from "react";
import "../Components/FitnessPlan.css";
export default function FitnessPlans() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const u = JSON.parse(localStorage.getItem("user"));
    setUser(u);
  }, []);

  return (
    <div className="component-wrapper">
      <h2 className="component-title">🏋️ Fitness Plan for {user?.fullName}</h2>
      <p className="component-desc">
        Your fitness goal: <b>{user?.fitnessGoal}</b>
      </p>
      <ul className="component-list">
        <li>💪 Strength training 3x a week</li>
        <li>🏃 30 mins cardio daily</li>
        <li>🧘 Stretching and yoga twice a week</li>
        <li>📅 Track progress regularly</li>
      </ul>
    </div>
  );
  
}
